#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"
#include "hardware/pwm.h"
#include "hardware/clocks.h"

const  BUZZER_PIN  = 21;
const  BUZZER_FREQUENCY = 10000;
void pwm_init_buzzer(uint pin) {
    // Configurar o pino como saída de PWM
    gpio_set_function(pin, GPIO_FUNC_PWM);

    // Obter o slice do PWM associado ao pino
    uint slice_num = pwm_gpio_to_slice_num(pin);

    // Configurar o PWM com frequência desejada
    pwm_config config = pwm_get_default_config();
    pwm_config_set_clkdiv(&config, clock_get_hz(clk_sys) / (BUZZER_FREQUENCY * 4096)); // Divisor de clock
    pwm_init(slice_num, &config, true);

    // Iniciar o PWM no nível baixo
    pwm_set_gpio_level(pin, 0);
}

void beep(uint pin, uint duration_ms) {
    // Obter o slice do PWM associado ao pino
    uint slice_num = pwm_gpio_to_slice_num(pin);

    // Configurar o duty cycle para 50% (ativo)
    pwm_set_gpio_level(pin, 1024);

    // Temporização
    sleep_ms(duration_ms);

    // Desativar o sinal PWM (duty cycle 0)
    pwm_set_gpio_level(pin, 0);

    // Pausa entre os beeps
    sleep_ms(500); // Pausa de 100ms
}

void sinal();
void pedestre();
const uint BUTTON_A_PIN = 6;
const uint AMARELO_LED_PIN= 12;   // LED azul no GPIO 12
const uint RED_LED_PIN  = 13; // LED vermelho no GPIO 13
const uint GREEN_LED_PIN = 11;  // LED verde no GPIO 11
const uint REDP_LED_PIN  = 10; // LED vermelho no GPIO 10 (PEDESTRE)
const uint GREENP_LED_PIN = 9;  


int main() {
  
  gpio_init(BUTTON_A_PIN);
  gpio_set_dir(BUTTON_A_PIN, GPIO_IN);
  gpio_pull_up(BUTTON_A_PIN);

  gpio_init(RED_LED_PIN);
  gpio_init(GREEN_LED_PIN);
  gpio_init(AMARELO_LED_PIN);
  gpio_set_dir(RED_LED_PIN, GPIO_OUT);
  gpio_set_dir(GREEN_LED_PIN, GPIO_OUT);
  gpio_set_dir(AMARELO_LED_PIN, GPIO_OUT);
  gpio_put(RED_LED_PIN, 0);
  gpio_put(GREEN_LED_PIN, 0);
  gpio_put(AMARELO_LED_PIN, 0);

  gpio_init(REDP_LED_PIN);
  gpio_init(GREENP_LED_PIN);
  gpio_set_dir(REDP_LED_PIN, GPIO_OUT);
  gpio_set_dir(GREENP_LED_PIN, GPIO_OUT);
  gpio_put(REDP_LED_PIN, 0);
  gpio_put(GREENP_LED_PIN, 0);
  
  pwm_init_buzzer(BUZZER_PIN);

  while (true) {
     sinal();
  }
}

void sinal()
{
    gpio_put(REDP_LED_PIN, 1);
    gpio_put(GREENP_LED_PIN, 0);

    gpio_put(RED_LED_PIN, 0);
    gpio_put(AMARELO_LED_PIN, 0);
    gpio_put(GREEN_LED_PIN, 1);
    sleep_ms(8000);
    if (gpio_get(BUTTON_A_PIN) == 0)
    {
      pedestre();
      return; // ESSE RETURN SERVE PARA GARANTIR QUE OS CARROS PASSEM LOGO APÓS O CICLO DO PEDESTRE FOR REALIZADO
    }
    gpio_put(RED_LED_PIN, 0);
    gpio_put(AMARELO_LED_PIN, 1);
    gpio_put(GREEN_LED_PIN, 0);
    sleep_ms(2000);
    if (gpio_get(BUTTON_A_PIN) == 0)
    {
      pedestre();
      return;
    }

    gpio_put(RED_LED_PIN, 1);
    gpio_put(AMARELO_LED_PIN, 0);
    gpio_put(GREEN_LED_PIN, 0);
    sleep_ms(10000);
    if (gpio_get(BUTTON_A_PIN) == 0)
    {
      pedestre();
      return; 
    }
}

void pedestre()
{   
    gpio_put(RED_LED_PIN, 0);
    gpio_put(AMARELO_LED_PIN, 1);
    gpio_put(GREEN_LED_PIN, 0);
    sleep_ms(5000); 

    gpio_put(RED_LED_PIN, 1);
    gpio_put(AMARELO_LED_PIN, 0);
    gpio_put(GREEN_LED_PIN, 0);
    gpio_put(REDP_LED_PIN, 0);
    gpio_put(GREENP_LED_PIN, 1);
    //esse loop abaixo serve para contar os 15 segundos que o pedestre tem
    for(int i = 1; i<=15; i++){
      beep(BUZZER_PIN, 500); // período de 1s 
    }    
}
